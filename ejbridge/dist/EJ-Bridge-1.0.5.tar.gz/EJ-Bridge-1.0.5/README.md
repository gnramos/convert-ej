# ejbridge

Tools for translating questions between electronic judges.

## Installation

```
pip install -i https://test.pypi.org/simple/ EJ-Bridge
```

## Usage

Creating a xml file from the 'name_dir_question' question
```
ejbridge -q name_dir_question
```

Creating files from the questions inside the 'name_dir' directory
```
ejbridge -d name_dir
```
