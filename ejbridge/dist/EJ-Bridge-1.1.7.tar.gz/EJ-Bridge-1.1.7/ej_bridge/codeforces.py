def codeforces_to_intermediate():
    return
