# ejbridge

## Installation

```
pip install -i https://test.pypi.org/simple/ EJ-Bridge
```

## Usage

Creating coderunner questions from the codeforces questions inside the 'name_dir' directory
```
ejbridge -cftocr name_dir
```
