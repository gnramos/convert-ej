#include <iostream>

using namespace std;

int main() {

    /**
     * Escreva a sua solução aqui
     */

    return 0;
}