# MaratonaUnB.cls #

A classe MaratonaUnB utiliza a class [UnBExam](https://github.com/UnB-CIC/UnBExam) para compor um caderno de provas para a Maratona de Programação.

A forma mais simples de utilizar é copiar os arquivos (de ambas as classes) para o seu diretório local (geralmente '[~/texmf](https://en.wikibooks.org/wiki/LaTeX/Installing_Extra_Packages#Installing_a_package)').