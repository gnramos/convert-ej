import java.io.IOException;

/**
 * IMPORTANTE:
 *      O nome da classe deve ser "Main" para que a sua solução execute
 */
public class Main {

    public static void main(String[] args) throws IOException {

        /**
         * Escreva a sua solução aqui
         */

    }

}