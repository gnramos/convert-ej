#include <stdio.h>

int main() {

    /**
     * Escreva a sua solução aqui
     */

    return 0;
}