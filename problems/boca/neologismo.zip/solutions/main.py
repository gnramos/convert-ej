string = input()

if string == 'code':
    string = string[:-1]

print(string + 'ar')
