N = int(input())
numeros = [int(x) for x in input().split()]
numeros.sort()

ans = N

for i in range(len(numeros)):
    if i != numeros[i]:
        ans = i
        break
    
print(ans)
