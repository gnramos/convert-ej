#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

const int MIN_N = 1;
const int MAX_N = 1000;

int main(int argc, char* argv[]) {
    
    registerValidation(argc, argv);
    int n;
    n = inf.readInt(MIN_N,MAX_N,"N");
    inf.readEoln();
    
    for(int i=1;i<=n-1;i++){
        inf.readInt(1,n,"a1");
        inf.readSpace();
    }
    inf.readInt(1,n,"a1");
    inf.readEoln();
    inf.readEof();
    return 0;
}
