#include<bits/stdc++.h>
 
using namespace std;
 
int main()
{
    int i,j,n,vagaoAtual;
    stack<int> vagoes;

    scanf("%d",&n);
    
    j = 0;
        
    for(int i = 0; i < n; i++)
    {
        scanf("%d", &vagaoAtual);
 
        while(j < n && j != vagaoAtual)
        {
            if(vagoes.size() > 0 && vagoes.top() == vagaoAtual)
                break;
                
                j++;
                
                vagoes.push(j);
        }
            
        if(vagoes.top() == vagaoAtual)
            vagoes.pop();
    }
        
    if(vagoes.size() == 0)
    {
        printf("sim\n");
    }
    else
    {
        printf("nao\n");
    }
        
    return 0;
}
