N = int(input())
total = N * (N + 1) // 2
print(total - sum(int(x) for x in input().split()))
