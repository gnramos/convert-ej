#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios::sync_with_stdio(false);

    int N;
    
    cin >> N;
    
    vector<int> ns(N + 1);
    iota(ns.begin(), ns.end(), 0);

    set<int> xs(ns.begin(), ns.end());

    for (int i = 0; i < N; ++i)
    {
        int x;
        cin >> x;

        xs.erase(x);
    }

    cout << *xs.begin() << '\n';

    return 0;
}
