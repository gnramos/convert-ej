import random
import sys

random.seed(sys.argv[1])

N = random.randint(1, 100)

numbers = [x for x in range(0, N + 1)]
random.shuffle(numbers)
numbers.pop()

print(N)
print(' '.join(str(x) for x in numbers))
