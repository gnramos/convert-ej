#include "testlib.h"

using namespace std;

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);

    int N, n;
    vector<int> v(101, 0);
    
    N = inf.readInt(1, 100, "N");
    inf.readEoln();
    
    for(auto i = 1; i < N; i++) {
        n = inf.readInt(0, N, "n");
        inf.readSpace();

        ensuref(v[n] == 0, "Duplicated value %d! [testcase %d]", n, i);
        v[n] = 1;
    }

    n = inf.readInt(0, N, "n");
    ensuref(v[n] == 0, "Duplicated value %d! [testcase %d]", n, N);

    inf.readEoln();
    inf.readEof();

    return 0;
}
