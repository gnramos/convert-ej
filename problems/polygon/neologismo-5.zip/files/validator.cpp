#include "testlib.h"
#include <string>

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);
    std::string s = inf.readString("[a-z]{1,50}");
    inf.readEof();
}
