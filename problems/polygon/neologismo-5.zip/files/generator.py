#!/usr/bin/env python

import random
import string
import sys

random.seed(int(sys.argv[1]))

for x in range(1, 11):
    s = ''.join(random.choice(string.ascii_lowercase)
                for _ in range(random.randint(1, 50)))

print(s)
