#include <bits/stdc++.h>

using namespace std;

int main()
{
    ios::sync_with_stdio(false);

    set<string> xs;
    string s;

    while (cin >> s)
        xs.insert(s);

    vector<string> ys { "Rodolfo", "Corredora", "Dancarina", "Empinadora", "Raposa", "Cometa", "Cupido", "Trovao", "Relampago" }, ans; 

    for (auto y : ys)
        if (xs.count(y) == 0)
            ans.push_back(y);

    for (size_t i = 0; i < ans.size(); ++i)
        cout << ans[i] << (i + 1 == ans.size() ? '\n' : ' ');

    return 0;
}
