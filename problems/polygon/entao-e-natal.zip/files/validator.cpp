#include "testlib.h"

using namespace std;

int main(int argc, char* argv[]) {
    registerValidation(argc, argv);

    string s;
    int i = 0;
    do {
        s = inf.readToken("Rodolfo|Corredora|Dancarina|Empinadora|Raposa|Cometa|Cupido|Trovao|Relampago","rena");

        ++i;
        inf.readEoln();
    } while(!inf.eof());
    
    inf.readEof();

    ensure(i > 0, "É preciso dar pelo menos um nome.");
    ensure(i < 10, "No máximo 9 nomes podem ser dados.");

    return 0;
}
