import random
import sys

renas = ['Rodolfo', 'Corredora', 'Dancarina', 'Empinadora', 'Raposa',
         'Cometa', 'Cupido', 'Trovao', 'Relampago']

random.seed(sys.argv[1])

for _ in range(random.randint(1, len(renas))):
    print(random.choice(renas))
