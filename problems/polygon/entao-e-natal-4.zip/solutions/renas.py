renas = ['Rodolfo', 'Corredora', 'Dancarina', 'Empinadora', 'Raposa',
         'Cometa', 'Cupido', 'Trovao', 'Relampago']

try:
    while True:
        r = input()
        if r in renas:
            renas.remove(r)
except:
    pass

print(' '.join(r for r in renas))
