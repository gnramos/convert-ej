import sys
renas = ['Rodolfo', 'Corredora', 'Dancarina', 'Empinadora',
		 'Raposa', 'Cometa', 'Cupido', 'Trovao', 'Relampago']

musica = [line.rstrip() for line in sys.stdin]

print(' '.join(rena for rena in renas if rena not in musica))

