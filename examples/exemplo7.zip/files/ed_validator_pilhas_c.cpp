#include <bits/stdc++.h>
#include "testlib.h"

using namespace std;

int main(int argc, char* argv[])
{
    registerValidation(argc, argv);

    string n = inf.readString();
    //ensure(n.find("0") != string::npos);
    //inf.readSpace();
    //inf.readInt(1, 9, "k");
    //inf.readEoln();

    //InStream nStream(inf, n);
    //nStream.readInt(0, 2000000000, "n");

    inf.readEof();
    return 0;
}
