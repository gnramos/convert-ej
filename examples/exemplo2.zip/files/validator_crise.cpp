#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

const int MIN_N = 13;
const int MAX_N = 100;


int main(int argc, char* argv[]) {
    
    registerValidation(argc, argv);
    int n;
    n = inf.readInt(MIN_N,MAX_N,"N");
    inf.readEoln();
    inf.readEof();
    return 0;
}
