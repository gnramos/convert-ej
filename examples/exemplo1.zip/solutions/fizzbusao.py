
veiculos, onibus = 0, 0
for c in input():
    veiculos += 1
    if c == 'O':
        onibus += 1

    if 0 == (veiculos % 3):
        if c == 'O' and 0 == (onibus % 5):
            print('fizzbusao')
        else:
            print('fizz')
    elif c == 'O' and 0 == (onibus % 5):
        print('busao')
    else:
        print(veiculos)
