#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

int main(int argc, char* argv[]) {
    
    registerValidation(argc, argv);
    string n = inf.readString();
    inf.readEof();
    return 0;
}
