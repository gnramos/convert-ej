#include "testlib.h"
#include <bits/stdc++.h>

using namespace std;

const int MIN_N = 1;
const int MAX_N = 1000;

const int number_of_rnd_tests = 40;

template <typename T> void append(vector<T> &dest, const vector<T> &orig) {
    dest.insert(dest.end(), orig.begin(), orig.end());
}

// Generate sample tests
vector<string> generate_sample_tests(void) {
    vector<string> tests = {"A\n","CBACBACBACBACBA\n","CCCCBBBBAAAA\n","ACMICPC\n","ABCDEFGHIJKLMNOPQRSTUVWXYZ\n","AAQGHIAEIBJAEFNHBAJKLWENHRGKLAJLKAWLREJIGNQRNHLEGJKLQBNWEVKLBMAEKLBN\n","ANKLAGRABZBQHERLUIGQYNOVIUEYQBNIWUECTMQOIWEUMZHJGCIWEYRNQIUWEY\n","AAQGHIAEIZ\n","KHJIGEFDDDDDABAA\n","ANKLAGRABZBQZ\n","LMNBXVB\n","ECJE\n","OHLSIQMEYMLV\n","VA\n","FPQ\n","UCU\n","UUXV\n","YDKW\n","XHHFU\n","PLSOQ\n","RZPQYR\n","MXNAHS\n","QEBSEUY\n","IQMNNEXY\n"
    };
    return tests;
}//24 examples

string random_test(int test_n) {

    int min_n = MIN_N;
    int max_n = MAX_N;
    int a;
    vector<int> asc;
    char c;
    
    for(int i = 0; i < 10; i++)
    {
        asc.push_back(i+65);
    }
    
    if (test_n < number_of_rnd_tests / 3) {
        // Easy
        min_n = 6;
        max_n = 20;
        
    } else if (test_n < 2 * number_of_rnd_tests / 3) {
        // Medium
        min_n = 15;
        max_n = 75;
    }
    
    ostringstream oss;
    
    int n = rnd.next(min_n, max_n);
    
    for(int i = 1; i < n; i++)
    {
        a = rnd.next(0,9);
        c = asc[a];
        oss << c ;
    }
    
    a = rnd.next(0,9);
    c = asc[a];
    oss << c << endl;

    return oss.str();
}

string max_test(int test_n) {

    ostringstream oss;
    vector<int> asc;
    char c;
    int a;
    
    for(int i = 0; i < 17; i++)
    {
        asc.push_back(i+65);
    }
    
    int n = MAX_N;
    
    for(int i = 1; i < n; i++)
    {
        a = rnd.next(0,16);
        c = asc[a];
        oss << c;
    }
    
    a = rnd.next(0,16);
    c = asc[a];
    oss << c << endl;
    
    return oss.str();
}


string min_test(int test_n) {

    ostringstream oss;
    
    oss << "1 1" << endl << "1" << endl;
    
    return oss.str();
}


vector<string> generate_random_tests() {
    vector<string> v;
    for (int i = 0; i < number_of_rnd_tests; i++) {
        v.push_back(random_test(i));
    }
    return v;
}

vector<string> generate_max_test() {
    vector<string> v;
    v.push_back(max_test(65));
    return v;
}

vector<string> generate_min_test() {
    vector<string> v;
    v.push_back(min_test(66));
    return v;
}

int main(int argc, char *argv[]) {
    
    registerGen(argc, argv, 1);
    vector<string> tests;
    size_t test = 0;
    append(tests, generate_sample_tests());
    append(tests, generate_random_tests());
    append(tests, generate_max_test());
    //append(tests, generate_min_test());

    for (const auto &t : tests) {
        startTest(++test);
        cout << t;
    }
    
    return 0;
}
