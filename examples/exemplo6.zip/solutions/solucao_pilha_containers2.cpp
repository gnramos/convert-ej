#include <bits/stdc++.h>
#define pb push_back
using namespace std;

int main()
{

    char str[1001];
    vector< stack<char> > stacks;
    bool maisUmaPilha;
    
    scanf("%s",str);

    for(int i =0; str[i] != '\0'; i++)
    {
        
        maisUmaPilha = false;
 
        for(int j =0; j < stacks.size(); j++)
        {
            if(stacks[j].top() >= str[i])
            {
                maisUmaPilha = true;
                stacks[j].push(str[i]);
                break;
            }
        }
 
        if(!maisUmaPilha)
        {
            stack<char> aux;
            aux.push(str[i]);
            stacks.pb(aux);
        }        
    }

    printf("%d\n", (int) stacks.size() );
 
    return 0;
}
